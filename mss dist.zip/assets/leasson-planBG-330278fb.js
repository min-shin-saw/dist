const s="/assets/leasson-planBG-dc7dd441.jpg";export{s as _};
