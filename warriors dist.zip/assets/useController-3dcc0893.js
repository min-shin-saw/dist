import{F as r}from"./index-8903d266.js";function e(){function n(){return r.get("/guardian/childs")}function o(t){return r.get("/guardian/dashboard?user_id="+t)}return{home:o,childs:n}}export{e as u};
