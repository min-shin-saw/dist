const s="/assets/calendar-default-b2fae90a.gif",a="/assets/no-live-session-d23d5a26.gif";export{s as _,a};
