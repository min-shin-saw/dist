import{_ as e,b as n,e as t}from"./index-74a33a67.js";const c={};function a(o,r){return n(),t("div",null," Assignment Detail ")}const _=e(c,[["render",a]]);export{_ as default};
